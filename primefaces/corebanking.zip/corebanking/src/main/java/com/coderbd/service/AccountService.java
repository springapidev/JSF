package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.AccountDao;
import com.coderbd.entity.Account;
import com.coderbd.entity.BalanceSummary;

public class AccountService extends CommonService<Account> implements AccountDao {
	@Override
	public Account findAccountNoBymobile(String mobile) throws Exception {
		return ((Account) getSession().createQuery("SELECT t from Account t where mobile='"+mobile+"'").getSingleResult());
	}
}
