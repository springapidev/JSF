package com.coderbd.dao;

import com.coderbd.common.CommonDao;
import com.coderbd.entity.AccountType;

public interface AccountTypeDao extends CommonDao<AccountType> {

}
