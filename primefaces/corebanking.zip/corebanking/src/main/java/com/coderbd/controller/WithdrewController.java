package com.coderbd.controller;

import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.coderbd.entity.Account;
import com.coderbd.entity.BalanceSummary;
import com.coderbd.entity.Withdrew;
import com.coderbd.service.AccountService;
import com.coderbd.service.BalanceSummaryService;
import com.coderbd.service.WithdrewService;

@SessionScoped
@ManagedBean(name = "withdrewController")
public class WithdrewController {

	final static Logger logger = Logger.getLogger(WithdrewController.class);
	private BalanceSummaryService balanceSummaryService;
	private BalanceSummary balanceSummary;

	private AccountService accountService;
	private Account account;

	private WithdrewService withdrewService;
	private Withdrew withdrew;
	private List<Withdrew> withdrews;

	private String renForm = "false";

	public void display() {
		try {
			accountService = new AccountService();
			Account ac = accountService.findById(account.getId());
			if (ac != null) {
				renForm = "true";
			}
		} catch (Exception e) {
			notificationSuccessNotExiist("Account Not Exist!");
		}
	}

	public String save() {

		try {
			withdrewService = new WithdrewService();
			balanceSummaryService = new BalanceSummaryService();
			if (account.getId() != 0) {
				Account ac = accountService.findById(account.getId());
				if (ac != null) {
					withdrew.setAccount(ac);
					withdrew.setWidthdrewDate(new Date());
					withdrewService.persist(withdrew);
					BalanceSummary ps = (BalanceSummary) balanceSummaryService.findBalanceSummaryByAccount(ac.getId());
					balanceSummary = new BalanceSummary();
					balanceSummary.setId(ps.getId());
					balanceSummary.setAccount(ac);
					balanceSummary.setAvailableBalance(ps.getAvailableBalance() - withdrew.getWithdrewAmount());
					balanceSummary.setTotalWithdrewAmount(ps.getTotalWithdrewAmount() + withdrew.getWithdrewAmount());
					balanceSummary.setTotalDepositAmount(ps.getTotalDepositAmount());
					balanceSummaryService.merge(balanceSummary);
					balanceSummary = null;
					withdrew = null;
				}
			}

		} catch (Exception e) {
			notificationError(e, "Persist Error!");
			logger.debug("This is debug :" + e);
			logger.error("This is error : " + e);
			logger.fatal("This is fatal : " + e);
		}
		return null;

	}

	public void notificationSuccess(String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.INFO, "Operation " + operation + " success");
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Notification", "Success");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void notificationError(Exception e, String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.ERROR, "Operation " + operation + " Error ", e);
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Notification", "Une erreur est survenue");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void notificationSuccessNotExiist(String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.ERROR,
				"Operation " + operation + " Account Already Exist!");
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Account Not Exist!", "Account Not Exist!");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public String getRenForm() {
		return renForm;
	}

	public void setRenForm(String renForm) {
		this.renForm = renForm;
	}

	public BalanceSummary getBalanceSummary() {
		if (balanceSummary == null) {
			balanceSummary = new BalanceSummary();
		}
		return balanceSummary;
	}

	public void setBalanceSummary(BalanceSummary balanceSummary) {
		this.balanceSummary = balanceSummary;
	}

	public Account getAccount() {
		if (account == null) {
			account = new Account();
		}
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Withdrew getWithdrew() {
		if (withdrew == null) {
			withdrew = new Withdrew();
		}
		return withdrew;
	}

	public void setWithdrew(Withdrew withdrew) {
		this.withdrew = withdrew;
	}

	public List<Withdrew> getWithdrews() {
		try{
			withdrewService = new WithdrewService();
			withdrews = withdrewService.findAll();
		} catch (Exception e) {
			notificationError(e, "Persist Error!");
			logger.debug("This is debug :" + e);
			logger.error("This is error : " + e);
			logger.fatal("This is fatal : " + e);
		}
		
		return withdrews;
	}

	public void setWithdrews(List<Withdrew> withdrews) {
		this.withdrews = withdrews;
	}

}
