package com.coderbd.dao;


import com.coderbd.common.CommonDao;
import com.coderbd.entity.Withdrew;

public interface WithdrewDao extends CommonDao<Withdrew>{

}
