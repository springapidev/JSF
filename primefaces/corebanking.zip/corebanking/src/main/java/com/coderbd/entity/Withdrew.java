package com.coderbd.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "withdrew_details")
public class Withdrew {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id")
    private int id;
	
	@Column(name = "withdrew_amount")
	private double withdrewAmount;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "widthdrew_date")
    private Date widthdrewDate;
	
	@ManyToOne
	@JoinColumn(name = "account_no",referencedColumnName="id")
	private Account account;
	
	@Column(name = "note")
	private  String note;

    public Withdrew() {
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	

	public double getWithdrewAmount() {
		return withdrewAmount;
	}

	public void setWithdrewAmount(double withdrewAmount) {
		this.withdrewAmount = withdrewAmount;
	}

	public Date getWidthdrewDate() {
		return widthdrewDate;
	}

	public void setWidthdrewDate(Date widthdrewDate) {
		this.widthdrewDate = widthdrewDate;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@Override
	public String toString() {
		return "Withdrew [id=" + id + ", withdrewAmount=" + withdrewAmount + ", widthdrewDate=" + widthdrewDate
				+ ", account=" + account + ", note=" + note + "]";
	}

	
	

}
