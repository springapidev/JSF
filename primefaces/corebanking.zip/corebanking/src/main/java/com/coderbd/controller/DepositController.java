package com.coderbd.controller;

import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.coderbd.entity.Account;
import com.coderbd.entity.BalanceSummary;
import com.coderbd.entity.Deposit;
import com.coderbd.service.AccountService;
import com.coderbd.service.BalanceSummaryService;
import com.coderbd.service.DepositService;

@ManagedBean(name = "depositController")
@SessionScoped
public class DepositController {

	final static Logger logger = Logger.getLogger(DepositController.class);
	private BalanceSummaryService balanceSummaryService;
	private BalanceSummary balanceSummary;

	private AccountService accountService;
	private Account account;

	private DepositService depositService;
	private Deposit deposit;

	private List<Deposit> deposits;

	private String renForm = "false";

	public void display() {
		try {
			accountService = new AccountService();
			Account ac = accountService.findById(account.getId());
			if (ac != null) {
				renForm = "true";
			}
		} catch (Exception e) {
			notificationSuccessNotExiist("Account Not Exist!");
		}

	}

	public String save() {

		try {
			depositService = new DepositService();
			balanceSummaryService = new BalanceSummaryService();
			if (account.getId() != 0) {
				Account ac = accountService.findById(account.getId());
				if (ac != null) {
					deposit.setAccount(ac);
					deposit.setDepositDate(new Date());
					depositService.persist(deposit);
					BalanceSummary ps = (BalanceSummary) balanceSummaryService.findBalanceSummaryByAccount(ac.getId());
					balanceSummary = new BalanceSummary();
					balanceSummary.setId(ps.getId());
					balanceSummary.setAccount(ac);
					balanceSummary.setAvailableBalance(ps.getAvailableBalance() + deposit.getDepositAmount());
					balanceSummary.setTotalDepositAmount(ps.getTotalDepositAmount() + deposit.getDepositAmount());
					balanceSummary.setTotalWithdrewAmount(ps.getTotalWithdrewAmount());
					balanceSummaryService.merge(balanceSummary);
					balanceSummary = null;
					deposit = null;
				}
			}

		} catch (Exception e) {
			notificationError(e, "Persist Error!");
			logger.debug("This is debug :" + e);
			logger.error("This is error : " + e);
			logger.fatal("This is fatal : " + e);
		}
		return null;

	}

	public void notificationSuccess(String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.INFO, "Operation " + operation + " success");
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Success", "Success");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void notificationError(Exception e, String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.ERROR, "Operation " + operation + " Error ", e);
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Errror", "Errror");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void notificationSuccessNotExiist(String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.ERROR,
				"Operation " + operation + " Account Already Exist!");
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Account Not Exist!", "Account Not Exist!");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public BalanceSummary getBalanceSummary() {
		if (balanceSummary == null) {
			balanceSummary = new BalanceSummary();
		}
		return balanceSummary;
	}

	public void setBalanceSummary(BalanceSummary balanceSummary) {
		this.balanceSummary = balanceSummary;
	}

	public Account getAccount() {
		if (account == null) {
			account = new Account();
		}
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Deposit getDeposit() {
		if (deposit == null) {
			deposit = new Deposit();
		}
		return deposit;
	}

	public void setDeposit(Deposit deposit) {
		this.deposit = deposit;
	}

	public List<Deposit> getDeposits() {
		try {
			depositService = new DepositService();
			deposits = depositService.findAll();
		} catch (Exception e) {
			notificationError(e, "Persist Error!");
			logger.debug("This is debug :" + e);
			logger.error("This is error : " + e);
			logger.fatal("This is fatal : " + e);
		}
		return deposits;
	}

	public void setDeposits(List<Deposit> deposits) {
		this.deposits = deposits;
	}

	public String getRenForm() {
		return renForm;
	}

	public void setRenForm(String renForm) {
		this.renForm = renForm;
	}

	

}
