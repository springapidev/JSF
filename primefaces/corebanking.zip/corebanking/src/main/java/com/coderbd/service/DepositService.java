package com.coderbd.service;

import java.util.List;

import com.coderbd.common.CommonService;
import com.coderbd.dao.DepositDao;
import com.coderbd.entity.Deposit;

public class DepositService extends CommonService<Deposit> implements DepositDao {
	@SuppressWarnings("unchecked")
	@Override
	public List<Deposit> findAllDepositByAccountID(int id) throws Exception {
		return ((List<Deposit>) getSession().createQuery("SELECT t from Deposit t where account.id='"+id+"'").getResultList());
	}
}
