package com.coderbd.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "account_info")
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id")
    private int id;
	@Column(name = "account_holder")
    private String accountHolder;
	@Column(name = "email")
    private String email;
	@Column(name = "mobile")
    private String mobile;
	@Column(name = "nid")
    private String nid;
	@Column(name = "address")
    private String address;
	@Column(name = "opening_balance")
    private double openingBalance;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "ac_opening_date")
    private Date accountOpeningDate;
	
	@ManyToOne
	@JoinColumn(name = "account_type_id",referencedColumnName="id")
	private AccountType accountType;
  
    public Account() {
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getNid() {
		return nid;
	}

	public void setNid(String nid) {
		this.nid = nid;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public Date getAccountOpeningDate() {
		return accountOpeningDate;
	}

	public void setAccountOpeningDate(Date accountOpeningDate) {
		this.accountOpeningDate = accountOpeningDate;
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", accountHolder=" + accountHolder + ", email=" + email + ", mobile=" + mobile
				+ ", nid=" + nid + ", address=" + address + ", openingBalance=" + openingBalance
				+ ", accountOpeningDate=" + accountOpeningDate + ", accountType=" + accountType + "]";
	}

	
	
}
