package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.WithdrewDao;
import com.coderbd.entity.Withdrew;

public class WithdrewService extends CommonService<Withdrew> implements WithdrewDao{

}
