package com.coderbd.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "balance_summary")
public class BalanceSummary {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id")
    private int id;
	
		
	@Column(name = "total_deposit_amount")
	private double totalDepositAmount;
	
	@Column(name = "total_widthdew_amount")
	private double totalWithdrewAmount;
	
	@Column(name = "available_balance")
	private double availableBalance;

	
	@OneToOne
	@JoinColumn(name = "account_no",referencedColumnName="id")
	private Account account;
	
	
	
    public BalanceSummary() {
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public double getTotalDepositAmount() {
		return totalDepositAmount;
	}

	public void setTotalDepositAmount(double totalDepositAmount) {
		this.totalDepositAmount = totalDepositAmount;
	}

	public double getTotalWithdrewAmount() {
		return totalWithdrewAmount;
	}

	public void setTotalWithdrewAmount(double totalWithdrewAmount) {
		this.totalWithdrewAmount = totalWithdrewAmount;
	}

	public double getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(double availableBalance) {
		this.availableBalance = availableBalance;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "BalanceSummary [id=" + id + ", totalDepositAmount=" + totalDepositAmount + ", totalWithdrewAmount="
				+ totalWithdrewAmount + ", availableBalance=" + availableBalance + ", account=" + account + "]";
	}

	
}
