package com.coderbd.controller;

import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.transaction.Transactional;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.coderbd.entity.Account;
import com.coderbd.entity.AccountType;
import com.coderbd.entity.BalanceSummary;
import com.coderbd.entity.Deposit;
import com.coderbd.service.AccountService;
import com.coderbd.service.BalanceSummaryService;
import com.coderbd.service.DepositService;

@ManagedBean(name = "accountController")
public class AccountController {
	final static Logger logger = Logger.getLogger(AccountController.class);

	private BalanceSummaryService balanceSummaryService;
	private BalanceSummary balanceSummary;

	private AccountType accountType;

	private AccountService accountService;
	private Account account;
	private List<Account> accounts;

	@Transactional
	public String save() {
		accountService = new AccountService();
		balanceSummaryService = new BalanceSummaryService();
		DepositService depositService = new DepositService();
		try {
			account.setAccountType(accountType);
			account.setAccountOpeningDate(new Date());
			balanceSummary = new BalanceSummary();
			balanceSummary.setTotalDepositAmount(account.getOpeningBalance());
			balanceSummary.setAvailableBalance(account.getOpeningBalance());
			Account ac = accountService.findAccountNoBymobile(account.getMobile());
			
			if (ac != null) {
				notificationSuccessAlready("Account Already Exist!");
			}
		} catch (Exception e) {

			try {
				
				accountService.persist(account);
				Account acc = accountService.findAccountNoBymobile(account.getMobile());
				
				Deposit deposit=new Deposit();
				deposit.setDepositAmount(account.getOpeningBalance());
				deposit.setDepositDate(new Date());
				deposit.setAccount(acc);
				deposit.setNote("Opening Balance");
				depositService.persist(deposit);
				
				balanceSummary.setAccount(acc);
				balanceSummaryService.persist(balanceSummary);
				account = null;
				balanceSummary = null;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			notificationError(e, "Persist Error!");
			logger.debug("This is debug :" + e);
			logger.error("This is error : " + e);
			logger.fatal("This is fatal : " + e);
		}
		return null;

	}

	public Account getAccount() {
		if (account == null) {
			account = new Account();
		}
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public AccountType getAccountType() {
		if (accountType == null) {
			accountType = new AccountType();
		}
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public List<Account> getAccounts() {
		try {
			accountService = new AccountService();
			accounts = accountService.findAll();
		} catch (Exception e) {
			notificationError(e, "Persist Error!");
			logger.debug("This is debug :" + e);
			logger.error("This is error : " + e);
			logger.fatal("This is fatal : " + e);
		}
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	
	public BalanceSummary getBalanceSummary() {
		if(balanceSummary ==  null ){
			balanceSummary =new BalanceSummary();
		}
		return balanceSummary;
	}

	public void setBalanceSummary(BalanceSummary balanceSummary) {
		this.balanceSummary = balanceSummary;
	}

	public void notificationSuccess(String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.INFO, "Operation " + operation + " success");
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Notification", "Success");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}
	
	public void notificationSuccessAlready(String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.ERROR, "Operation " + operation + " Account Already Exist!");
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Account Already Exist!", "Account Already Exist!");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void notificationError(Exception e, String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.ERROR, "Operation " + operation + " Error ", e);
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Notification", "Une erreur est survenue");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

}
