package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.BalanceSummaryDao;
import com.coderbd.entity.BalanceSummary;

public class BalanceSummaryService extends CommonService<BalanceSummary> implements BalanceSummaryDao {
	@Override
	public BalanceSummary findBalanceSummaryByAccount(int id) throws Exception {
		return ((BalanceSummary) getSession().createQuery("SELECT t from BalanceSummary t where account.id='"+id+"'").getSingleResult());
	}
	
	
}
