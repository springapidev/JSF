package com.coderbd.dao;



import com.coderbd.common.CommonDao;
import com.coderbd.entity.BalanceSummary;


public interface BalanceSummaryDao extends CommonDao<BalanceSummary> {
	public BalanceSummary findBalanceSummaryByAccount(int id) throws Exception;
}
