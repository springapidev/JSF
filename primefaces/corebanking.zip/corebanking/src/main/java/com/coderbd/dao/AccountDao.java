package com.coderbd.dao;

import com.coderbd.common.CommonDao;
import com.coderbd.entity.Account;

public interface AccountDao extends CommonDao<Account> {
	public Account findAccountNoBymobile(String mobile) throws Exception;
}
