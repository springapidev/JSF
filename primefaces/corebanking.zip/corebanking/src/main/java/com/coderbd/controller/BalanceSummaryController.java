package com.coderbd.controller;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.coderbd.entity.Account;
import com.coderbd.entity.BalanceSummary;
import com.coderbd.service.AccountService;
import com.coderbd.service.BalanceSummaryService;

@ViewScoped
@ManagedBean(name="balanceSummaryController")
public class BalanceSummaryController {
	final static Logger logger = Logger.getLogger(BalanceSummaryController.class);

	private BalanceSummaryService balanceSummaryService;
	private BalanceSummary balanceSummary;

	private List<BalanceSummary> balanceSummaries;

	
	public String save() {
		try {

			balanceSummaryService = new BalanceSummaryService();
			balanceSummaryService.persist(balanceSummary);

			notificationSuccess("Persist Success!");
			balanceSummary = null;

		} catch (Exception e) {
			notificationError(e, "Persist Error!");
			logger.debug("This is debug :" + e);
			logger.error("This is error : " + e);
			logger.fatal("This is fatal : " + e);
		}
		return null;

	}

	public void notificationSuccess(String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.INFO, "Operation " + operation + " success");
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Success", "Success");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void notificationError(Exception e, String operation) {
		Logger.getLogger(this.getClass().getName()).log(Level.ERROR, "Operation " + operation + " Error ", e);
		FacesMessage msg = null;
		msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Error", "Error");
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public BalanceSummary getBalanceSummary() {
		if (balanceSummary == null) {
			balanceSummary = new BalanceSummary();
		}
		return balanceSummary;
	}

	public void setBalanceSummary(BalanceSummary balanceSummary) {
		this.balanceSummary = balanceSummary;
	}

	public List<BalanceSummary> getBalanceSummaries() {
		try {
			balanceSummaryService = new BalanceSummaryService();
			balanceSummaries = balanceSummaryService.findAll();
		} catch (Exception e) {
			notificationError(e, "Persist Error!");
			logger.debug("This is debug :" + e);
			logger.error("This is error : " + e);
			logger.fatal("This is fatal : " + e);
		}
		return balanceSummaries;
	}

	public void setBalanceSummaries(List<BalanceSummary> balanceSummaries) {
		this.balanceSummaries = balanceSummaries;
	}

	//////////////////////////////// Mini Statement//////////////////////////
	private int accountID;
	private String renPanel = "false";

	private BalanceSummary balanceSummaryByAccount;

	public void loadStatement() {
		if (accountID != 0) {
			try {
				AccountService accountService = new AccountService();

				Account acc = accountService.findById(accountID);
				if (acc != null) {
					balanceSummaryService = new BalanceSummaryService();
					balanceSummaryByAccount = balanceSummaryService.findBalanceSummaryByAccount(acc.getId());
					renPanel = "true";
					
					System.out.println("balanceSummaryByAccount::::: "+balanceSummaryByAccount.getAccount().getAccountHolder());
				}
			} catch (Exception e) {
				notificationError(e, "Persist Error!");
				logger.debug("This is debug :" + e);
				logger.error("This is error : " + e);
				logger.fatal("This is fatal : " + e);
			}
		}

	}

	public int getAccountID() {
		return accountID;
	}

	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	public String getRenPanel() {
		return renPanel;
	}

	public void setRenPanel(String renPanel) {
		this.renPanel = renPanel;
	}

	public BalanceSummary getBalanceSummaryByAccount() {
		if (balanceSummaryByAccount == null) {
			balanceSummaryByAccount = new BalanceSummary();
		}
		return balanceSummaryByAccount;
	}

	public void setBalanceSummaryByAccount(BalanceSummary balanceSummaryByAccount) {
		this.balanceSummaryByAccount = balanceSummaryByAccount;
	}

}
