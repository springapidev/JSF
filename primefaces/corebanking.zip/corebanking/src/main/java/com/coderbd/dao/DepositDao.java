package com.coderbd.dao;

import java.util.List;

import com.coderbd.common.CommonDao;
import com.coderbd.entity.Deposit;


public interface DepositDao extends CommonDao<Deposit>{
	public List<Deposit> findAllDepositByAccountID(int id) throws Exception;
}
