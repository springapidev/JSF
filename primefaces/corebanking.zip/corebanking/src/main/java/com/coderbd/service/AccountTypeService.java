package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.AccountTypeDao;
import com.coderbd.entity.AccountType;

public class AccountTypeService extends CommonService<AccountType> implements AccountTypeDao {

}
