package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.MarksInputDao;
import com.coderbd.entity.MarksInput;

public class MarksInputService extends CommonService<MarksInput> implements MarksInputDao {

}
