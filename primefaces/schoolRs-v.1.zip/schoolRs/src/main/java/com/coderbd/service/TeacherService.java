package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.TeacherDao;
import com.coderbd.entity.Teacher;

public class TeacherService extends CommonService<Teacher> implements TeacherDao {

}
