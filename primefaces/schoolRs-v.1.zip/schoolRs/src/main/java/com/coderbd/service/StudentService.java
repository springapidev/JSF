package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.StudentDao;
import com.coderbd.entity.Student;import java.io.Serializable;
;

public class StudentService extends CommonService<Student> implements StudentDao, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
