package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.SubjectDao;
import com.coderbd.entity.Subject;


public class SubjectService extends CommonService<Subject> implements SubjectDao {

}
