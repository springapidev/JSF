package com.coderbd.dao;

import com.coderbd.common.CommonDao;
import com.coderbd.entity.StudentSubsMarks;

public interface StudentSubsMarksDao extends CommonDao<StudentSubsMarks> {

}
