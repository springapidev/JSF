package com.coderbd.dao;

import com.coderbd.common.CommonDao;
import com.coderbd.entity.Student;

public interface StudentDao extends CommonDao<Student>{

}
