package com.coderbd.dao;

import com.coderbd.common.CommonDao;
import com.coderbd.entity.MarksInput;

public interface MarksInputDao extends CommonDao<MarksInput> {

}
