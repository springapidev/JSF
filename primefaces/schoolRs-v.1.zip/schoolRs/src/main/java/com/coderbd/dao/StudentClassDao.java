package com.coderbd.dao;

import com.coderbd.common.CommonDao;
import com.coderbd.entity.StudentClass;

public interface StudentClassDao extends CommonDao<StudentClass>{

}
