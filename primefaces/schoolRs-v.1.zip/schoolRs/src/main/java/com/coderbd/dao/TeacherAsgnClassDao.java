package com.coderbd.dao;

import com.coderbd.common.CommonDao;
import com.coderbd.entity.TeacherAsgnClass;

public interface TeacherAsgnClassDao extends CommonDao<TeacherAsgnClass> {

}
