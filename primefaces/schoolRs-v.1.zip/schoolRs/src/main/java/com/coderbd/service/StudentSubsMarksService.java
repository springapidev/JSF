package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.StudentSubsMarksDao;
import com.coderbd.entity.StudentSubsMarks;

public class StudentSubsMarksService extends CommonService<StudentSubsMarks> implements StudentSubsMarksDao {

}
