package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.StudentClassDao;
import com.coderbd.entity.StudentClass;

public class StudentClassService extends CommonService<StudentClass> implements StudentClassDao{

}
