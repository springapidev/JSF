package com.coderbd.service;

import com.coderbd.common.CommonService;
import com.coderbd.dao.TeacherAsgnClassDao;
import com.coderbd.entity.TeacherAsgnClass;

public class TeacherAsgnClassService extends CommonService<TeacherAsgnClass> implements TeacherAsgnClassDao{

}
