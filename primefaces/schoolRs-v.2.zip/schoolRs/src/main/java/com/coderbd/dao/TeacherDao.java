package com.coderbd.dao;

import com.coderbd.common.CommonDao;
import com.coderbd.entity.Teacher;


public interface TeacherDao extends CommonDao<Teacher> {

}
